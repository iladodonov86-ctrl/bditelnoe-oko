package com.nkvd.oko.web;
import com.nkvd.oko.model.Denounce;
import com.nkvd.oko.service.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
@Controller @RequestMapping("/denounce")
public class DenounceController {
 private final DenounceService svc; private final TopicService topics;
 public DenounceController(DenounceService s,TopicService t){svc=s;topics=t;}
 @GetMapping("/new") public String form(Model m,Authentication a){
  m.addAttribute("topics",topics.active());m.addAttribute("username",a.getName());
  m.addAttribute("reasons",new String[]{"Антисоветская агитация","Хранение запрещённой литературы","Шпионаж в пользу иностранного государства","Связь с врагами народа","Хранение оружия без разрешения","Распространение слухов","Кулацкое прошлое","Прослушивание зарубежных радиопередач","Хранение иностранной валюты","Поддельные документы"});
  return "denounce-form";
 }
 @PostMapping("/new") public String create(@RequestParam String targetName,@RequestParam String targetAddress,@RequestParam String reason,@RequestParam(required=false) String details,@RequestParam(required=false) String topicPrefix,Authentication a){
  Denounce d=new Denounce();d.setAuthorUsername(a.getName());d.setAuthorName(a.getName());d.setTargetName(targetName);d.setTargetAddress(targetAddress);d.setReason(reason);d.setDetails(details);d.setTopicPrefix(topicPrefix);svc.create(d);return "redirect:/denounce/my";
 }
 @GetMapping("/my") public String mine(Model m,Authentication a){m.addAttribute("list",svc.mine(a.getName()));m.addAttribute("username",a.getName());return "denounce-list";}
 @GetMapping("/all") @PreAuthorize("hasAnyRole('INSPECTOR','COMMISSAR','ADMIN','SUPERADMIN')")
 public String all(Model m,Authentication a){m.addAttribute("list",svc.all());m.addAttribute("username",a.getName());return "denounce-list";}
 @GetMapping("/{id}") public String view(@PathVariable Long id,Model m,Authentication a){
  var d=svc.find(id).orElseThrow();if(!d.getAuthorUsername().equals(a.getName())&&!a.getAuthorities().stream().anyMatch(x->x.getAuthority().matches("ROLE_(INSPECTOR|COMMISSAR|ADMIN|SUPERADMIN)")))return "redirect:/denounce/my";
  m.addAttribute("d",d);m.addAttribute("username",a.getName());return "denounce-view";
 }
 @PostMapping("/{id}/status") @PreAuthorize("hasAnyRole('INSPECTOR','COMMISSAR','ADMIN','SUPERADMIN')")
 public String status(@PathVariable Long id,@RequestParam String status,@RequestParam(required=false) String assignedTo){if(!java.util.Set.of("НОВЫЙ","В РАБОТЕ","ЗАКРЫТ","ОТКЛОНЁН").contains(status))return "redirect:/denounce/"+id;svc.update(id,status,assignedTo);return "redirect:/denounce/"+id;}
 @PostMapping("/{id}/delete") @PreAuthorize("hasAnyRole('COMMISSAR','ADMIN','SUPERADMIN')")
 public String delete(@PathVariable Long id){svc.delete(id);return "redirect:/denounce/all";}
}
