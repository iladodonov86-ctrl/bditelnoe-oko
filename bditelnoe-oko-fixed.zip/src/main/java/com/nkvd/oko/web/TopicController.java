package com.nkvd.oko.web;
import com.nkvd.oko.model.Topic;
import com.nkvd.oko.service.TopicService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
@Controller @RequestMapping("/topics")
public class TopicController {
 private final TopicService svc; public TopicController(TopicService s){svc=s;}
 @GetMapping public String list(Model m){m.addAttribute("topics",svc.all());return "topics";}
 @GetMapping("/new") public String form(Model m){m.addAttribute("topic",new Topic());return "topic-form";}
 @GetMapping("/{id}/edit") public String edit(@PathVariable Long id,Model m){m.addAttribute("topic",svc.find(id).orElseThrow());return "topic-form";}
 @PostMapping("/save") public String save(@ModelAttribute Topic topic){svc.save(topic);return "redirect:/topics";}
 @PostMapping("/{id}/delete") public String delete(@PathVariable Long id){svc.delete(id);return "redirect:/topics";}
}
