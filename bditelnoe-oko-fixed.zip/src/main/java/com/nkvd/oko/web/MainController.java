package com.nkvd.oko.web;
import com.nkvd.oko.repo.*;
import com.nkvd.oko.service.AuditService;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
@Controller
public class MainController {
 private final DenounceRepository denounces; private final UserRepository users; private final AuditLogRepository audit;
 public MainController(DenounceRepository d,UserRepository u,AuditLogRepository a){denounces=d;users=u;audit=a;}
 @GetMapping("/") public String home(){return "redirect:/dashboard";}
 @GetMapping("/login") public String login(){return "login";}
 @GetMapping("/dashboard") public String dashboard(Model m,Authentication auth){
  var all=denounces.findAllByOrderByCreatedAtDesc();
  m.addAttribute("newCount",all.stream().filter(d->"НОВЫЙ".equals(d.getStatus())).count());
  m.addAttribute("closedCount",all.stream().filter(d->"ЗАКРЫТ".equals(d.getStatus())).count());
  m.addAttribute("totalDenounces",all.size());m.addAttribute("userCount",users.count());
  m.addAttribute("latest",all.stream().limit(8).toList());m.addAttribute("username",auth.getName());return "dashboard";
 }
}
