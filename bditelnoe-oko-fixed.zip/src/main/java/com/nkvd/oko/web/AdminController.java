package com.nkvd.oko.web;
import com.nkvd.oko.model.*;
import com.nkvd.oko.service.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import java.util.*;
@Controller @RequestMapping("/admin") @PreAuthorize("hasAnyRole('ADMIN','SUPERADMIN')")
public class AdminController {
 private final UserService users; private final AuditService audit;
 public AdminController(UserService u,AuditService a){users=u;audit=a;}
 @GetMapping("/users") public String users(Model m){m.addAttribute("users",users.all());return "admin-users";}
 @GetMapping("/users/new") public String createForm(Model m){m.addAttribute("editUser",new User());m.addAttribute("allRoles",Role.values());return "admin-user-form";}
 @PostMapping("/users/create") public String create(@RequestParam String username,@RequestParam String password,@RequestParam(required=false) String fullName,@RequestParam(required=false) String rank,@RequestParam(required=false) List<String> roles){
  Set<Role> rs=parseRoles(roles);if(rs.isEmpty())rs.add(Role.CITIZEN);users.create(username,password,fullName,rank,rs);return "redirect:/admin/users";
 }
 @GetMapping("/users/{id}/edit") public String edit(@PathVariable Long id,Model m){m.addAttribute("editUser",users.byId(id));m.addAttribute("allRoles",Role.values());return "admin-user-form";}
 @PostMapping("/users/{id}/update") public String update(@PathVariable Long id,@RequestParam(required=false) String fullName,@RequestParam(required=false) String rank,@RequestParam(required=false) String newPassword,@RequestParam(required=false) String active,@RequestParam(required=false) List<String> roles){
  Set<Role> rs=parseRoles(roles);if(rs.isEmpty())rs.add(Role.CITIZEN);
  // Only SUPERADMIN may grant or retain SUPERADMIN.
  User target=users.byId(id);
  users.update(id,fullName,rank,rs,active!=null,newPassword);return "redirect:/admin/users";
 }
 @PostMapping("/users/{id}/delete") public String delete(@PathVariable Long id){if(id!=1L)users.delete(id);return "redirect:/admin/users";}
 @GetMapping("/audit") public String audit(Model m){m.addAttribute("logs",audit.latest());return "audit";}
 private Set<Role> parseRoles(List<String> roles){Set<Role> set=EnumSet.noneOf(Role.class);if(roles!=null)for(String r:roles)try{set.add(Role.valueOf(r));}catch(Exception ignored){}return set;}
}
