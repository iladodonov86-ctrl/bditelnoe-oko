package com.nkvd.oko.web;
import com.nkvd.oko.service.UserService;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
@Controller
public class ProfileController {
 private final UserService users; public ProfileController(UserService u){users=u;}
 @GetMapping("/profile") public String profile(Authentication a,Model m){var u=users.find(a.getName()).orElseThrow();m.addAttribute("user",u);m.addAttribute("username",a.getName());m.addAttribute("rolesStr",users.rolesString(u));return "profile";}
}
