package com.nkvd.oko.repo;
import com.nkvd.oko.model.AuditLog;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface AuditLogRepository extends JpaRepository<AuditLog,Long> {
 List<AuditLog> findTop200ByOrderByCreatedAtDesc();
}
