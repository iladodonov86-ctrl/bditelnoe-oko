package com.nkvd.oko.repo;
import com.nkvd.oko.model.Denounce;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface DenounceRepository extends JpaRepository<Denounce,Long> {
 List<Denounce> findAllByOrderByCreatedAtDesc();
 List<Denounce> findByStatusOrderByCreatedAtDesc(String status);
 List<Denounce> findByAuthorUsernameOrderByCreatedAtDesc(String username);
}
