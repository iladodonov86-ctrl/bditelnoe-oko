package com.nkvd.oko.repo;
import com.nkvd.oko.model.Topic;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface TopicRepository extends JpaRepository<Topic,Long> {
 List<Topic> findAllByArchivedFalseOrderByPriorityDesc();
 boolean existsByPrefix(String prefix);
}
