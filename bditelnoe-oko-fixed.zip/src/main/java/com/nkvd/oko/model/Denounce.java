package com.nkvd.oko.model;
import jakarta.persistence.*;
import java.time.LocalDateTime;
@Entity @Table(name="denounces")
public class Denounce {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 private String authorName, authorUsername, targetName, targetAddress, reason;
 @Column(length=5000) private String details;
 private String topicPrefix;
 private String status="НОВЫЙ";
 private String assignedTo;
 private LocalDateTime createdAt=LocalDateTime.now(), updatedAt=LocalDateTime.now();
 public Long getId(){return id;} public void setId(Long v){id=v;}
 public String getAuthorName(){return authorName;} public void setAuthorName(String v){authorName=v;}
 public String getAuthorUsername(){return authorUsername;} public void setAuthorUsername(String v){authorUsername=v;}
 public String getTargetName(){return targetName;} public void setTargetName(String v){targetName=v;}
 public String getTargetAddress(){return targetAddress;} public void setTargetAddress(String v){targetAddress=v;}
 public String getReason(){return reason;} public void setReason(String v){reason=v;}
 public String getDetails(){return details;} public void setDetails(String v){details=v;}
 public String getTopicPrefix(){return topicPrefix;} public void setTopicPrefix(String v){topicPrefix=v;}
 public String getStatus(){return status;} public void setStatus(String v){status=v;}
 public String getAssignedTo(){return assignedTo;} public void setAssignedTo(String v){assignedTo=v;}
 public LocalDateTime getCreatedAt(){return createdAt;} public void setCreatedAt(LocalDateTime v){createdAt=v;}
 public LocalDateTime getUpdatedAt(){return updatedAt;} public void setUpdatedAt(LocalDateTime v){updatedAt=v;}
}
