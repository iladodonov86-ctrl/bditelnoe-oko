package com.nkvd.oko.model;
public enum Role { CITIZEN, AGENT, INSPECTOR, COMMISSAR, ADMIN, SUPERADMIN }
