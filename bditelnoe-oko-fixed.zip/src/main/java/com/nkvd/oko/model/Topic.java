package com.nkvd.oko.model;
import jakarta.persistence.*;
import java.time.LocalDateTime;
@Entity @Table(name="topics")
public class Topic {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 @Column(unique=true,nullable=false) private String prefix;
 private String description;
 private String color="#c0392b";
 private int priority=0;
 private boolean archived=false;
 private LocalDateTime createdAt=LocalDateTime.now();
 public Long getId(){return id;} public void setId(Long v){id=v;}
 public String getPrefix(){return prefix;} public void setPrefix(String v){prefix=v;}
 public String getDescription(){return description;} public void setDescription(String v){description=v;}
 public String getColor(){return color;} public void setColor(String v){color=v;}
 public int getPriority(){return priority;} public void setPriority(int v){priority=v;}
 public boolean isArchived(){return archived;} public void setArchived(boolean v){archived=v;}
 public LocalDateTime getCreatedAt(){return createdAt;} public void setCreatedAt(LocalDateTime v){createdAt=v;}
}
