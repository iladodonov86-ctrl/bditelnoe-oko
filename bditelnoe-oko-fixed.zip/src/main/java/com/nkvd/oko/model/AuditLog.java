package com.nkvd.oko.model;
import jakarta.persistence.*;
import java.time.LocalDateTime;
@Entity @Table(name="audit_log")
public class AuditLog {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 private String username, action;
 @Column(length=3000) private String details;
 private LocalDateTime createdAt=LocalDateTime.now();
 public AuditLog(){}
 public AuditLog(String u,String a,String d){username=u;action=a;details=d;createdAt=LocalDateTime.now();}
 public Long getId(){return id;} public String getUsername(){return username;} public void setUsername(String v){username=v;}
 public String getAction(){return action;} public void setAction(String v){action=v;}
 public String getDetails(){return details;} public void setDetails(String v){details=v;}
 public LocalDateTime getCreatedAt(){return createdAt;} public void setCreatedAt(LocalDateTime v){createdAt=v;}
}
