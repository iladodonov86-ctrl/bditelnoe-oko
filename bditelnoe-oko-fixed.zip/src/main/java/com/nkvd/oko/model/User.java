package com.nkvd.oko.model;
import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.*;
@Entity @Table(name="users")
public class User {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 @Column(unique=true, nullable=false) private String username;
 @Column(nullable=false) private String passwordHash;
 private String fullName;
 private String rank = "Рядовой";
 private boolean active = true;
 private LocalDateTime createdAt = LocalDateTime.now();
 private LocalDateTime lastLogin;
 private int denounceCount = 0;
 @ElementCollection(fetch=FetchType.EAGER) @Enumerated(EnumType.STRING)
 @CollectionTable(name="user_roles", joinColumns=@JoinColumn(name="user_id"))
 @Column(name="role_name") private Set<Role> roles = new HashSet<>();
 public Long getId(){return id;} public void setId(Long v){id=v;}
 public String getUsername(){return username;} public void setUsername(String v){username=v;}
 public String getPasswordHash(){return passwordHash;} public void setPasswordHash(String v){passwordHash=v;}
 public String getFullName(){return fullName;} public void setFullName(String v){fullName=v;}
 public String getRank(){return rank;} public void setRank(String v){rank=v;}
 public boolean isActive(){return active;} public void setActive(boolean v){active=v;}
 public LocalDateTime getCreatedAt(){return createdAt;} public void setCreatedAt(LocalDateTime v){createdAt=v;}
 public LocalDateTime getLastLogin(){return lastLogin;} public void setLastLogin(LocalDateTime v){lastLogin=v;}
 public int getDenounceCount(){return denounceCount;} public void setDenounceCount(int v){denounceCount=v;}
 public Set<Role> getRoles(){return roles;} public void setRoles(Set<Role> v){roles=v==null?new HashSet<>():v;}
}
