package com.nkvd.oko.config;
import com.nkvd.oko.model.*;
import com.nkvd.oko.repo.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;
import java.util.EnumSet;
@Configuration
public class DataInitializer {
 @Bean CommandLineRunner init(UserRepository users,TopicRepository topics,PasswordEncoder encoder,
    @Value("${oko.admin.username:President}") String adminName,
    @Value("${oko.admin.password:change-me-now}") String adminPassword){
  return args->{
   if(!users.existsByUsername(adminName)){
    User u=new User();u.setUsername(adminName);u.setPasswordHash(encoder.encode(adminPassword));
    u.setFullName("Президент Всея НКВД");u.setRank("Генеральный комиссар госбезопасности");
    u.setRoles(EnumSet.allOf(Role.class));users.save(u);
    System.out.println("Создан локальный демонстрационный администратор: "+adminName+" (пароль задаётся через OKO_ADMIN_PASSWORD)");
   }
   if(topics.count()==0){
    String[][] data={{"SECRET","СОВ. СЕКРЕТНО","#c0392b","100"},{"URGENT","СРОЧНО","#e67e22","80"},{"CASE","ДЕЛО","#3498db","60"},{"SPY","ШПИОНАЖ","#8e44ad","90"},{"ANTI","АНТИСОВЕТСКОЕ","#e74c3c","70"},{"SABOTAGE","ДИВЕРСИЯ","#16a085","85"},{"RUMOR","СЛУХИ","#f1c40f","40"},{"KULAK","КУЛАЦКОЕ","#7f8c8d","50"},{"CLEAN","ЧИСТО","#2ecc71","10"}};
    for(String[] row:data){Topic t=new Topic();t.setPrefix(row[0]);t.setDescription(row[1]);t.setColor(row[2]);t.setPriority(Integer.parseInt(row[3]));topics.save(t);}
   }
  };
 }
}
