package com.nkvd.oko.config;
import com.nkvd.oko.model.User;
import com.nkvd.oko.service.UserService;
import org.springframework.context.annotation.*;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.userdetails.*;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
@Configuration @EnableMethodSecurity
public class SecurityConfig {
 @Bean PasswordEncoder passwordEncoder(){return new BCryptPasswordEncoder();}
 @Bean UserDetailsService userDetailsService(UserService users){
  return username->{User u=users.find(username).orElseThrow(()->new UsernameNotFoundException("Пользователь не найден"));
   if(!u.isActive())throw new DisabledException("Учётная запись отключена");
   var authorities=u.getRoles().stream().map(r->"ROLE_"+r.name()).toList();
   return org.springframework.security.core.userdetails.User.withUsername(u.getUsername()).password(u.getPasswordHash()).authorities(authorities.toArray(String[]::new)).build();
  };
 }
 @Bean SecurityFilterChain filterChain(HttpSecurity http,UserService users)throws Exception{
  http.authorizeHttpRequests(a->a
    .requestMatchers("/css/**","/login","/error").permitAll()
    .requestMatchers("/admin/**").hasAnyRole("ADMIN","SUPERADMIN")
    .requestMatchers("/topics/**").hasAnyRole("COMMISSAR","ADMIN","SUPERADMIN")
    .requestMatchers("/denounce/new","/denounce/my").hasAnyRole("AGENT","INSPECTOR","COMMISSAR","ADMIN","SUPERADMIN")
    .requestMatchers("/denounce/all","/denounce/*/status","/denounce/*/delete").hasAnyRole("INSPECTOR","COMMISSAR","ADMIN","SUPERADMIN")
    .anyRequest().authenticated())
   .formLogin(f->f.loginPage("/login").successHandler((req,res,auth)->{users.touchLogin(auth.getName());res.sendRedirect("/dashboard");}).permitAll())
   .logout(l->l.logoutUrl("/logout").logoutSuccessUrl("/login?logout").permitAll())
   .headers(h->h.frameOptions(f->f.sameOrigin()));
  return http.build();
 }
}
