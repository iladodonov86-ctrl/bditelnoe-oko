package com.nkvd.oko.service;
import com.nkvd.oko.model.*;
import com.nkvd.oko.repo.*;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.*;
@Service
public class DenounceService {
 private final DenounceRepository repo; private final UserRepository users; private final AuditService audit;
 public DenounceService(DenounceRepository r,UserRepository u,AuditService a){repo=r;users=u;audit=a;}
 public List<Denounce> all(){return repo.findAllByOrderByCreatedAtDesc();}
 public List<Denounce> mine(String username){return repo.findByAuthorUsernameOrderByCreatedAtDesc(username);}
 public Optional<Denounce> find(Long id){return repo.findById(id);}
 public Denounce create(Denounce d){
  d.setCreatedAt(LocalDateTime.now());d.setUpdatedAt(LocalDateTime.now());if(d.getStatus()==null)d.setStatus("НОВЫЙ");
  Denounce saved=repo.save(d);users.findByUsername(d.getAuthorUsername()).ifPresent(u->{u.setDenounceCount(u.getDenounceCount()+1);users.save(u);});
  audit.log(d.getAuthorUsername(),"DENOUNCE_CREATE","Создана запись #"+saved.getId());return saved;
 }
 public Denounce update(Long id,String status,String assignedTo){
  Denounce d=repo.findById(id).orElseThrow();if(status!=null&&!status.isBlank())d.setStatus(status);
  if(assignedTo!=null)d.setAssignedTo(assignedTo);d.setUpdatedAt(LocalDateTime.now());
  audit.log("system","DENOUNCE_UPDATE","Обновлена запись #"+id);return repo.save(d);
 }
 public void delete(Long id){repo.deleteById(id);audit.log("system","DENOUNCE_DELETE","Удалена запись #"+id);}
}
