package com.nkvd.oko.service;
import com.nkvd.oko.model.*;
import com.nkvd.oko.repo.UserRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.*;
@Service
public class UserService {
 private final UserRepository repo; private final PasswordEncoder encoder; private final AuditService audit;
 public UserService(UserRepository r,PasswordEncoder e,AuditService a){repo=r;encoder=e;audit=a;}
 public Optional<User> find(String u){return repo.findByUsername(u);}
 public List<User> all(){return repo.findAll();}
 public User byId(Long id){return repo.findById(id).orElseThrow();}
 public User create(String username,String password,String fullName,String rank,Set<Role> roles){
  User u=new User();u.setUsername(username);u.setPasswordHash(encoder.encode(password));u.setFullName(fullName);u.setRank(rank);u.setRoles(roles);u.setActive(true);
  User saved=repo.save(u);audit.log(username,"USER_CREATE","Создан пользователь "+username);return saved;
 }
 public User update(Long id,String fullName,String rank,Set<Role> roles,Boolean active,String newPassword){
  User u=byId(id);u.setFullName(fullName);u.setRank(rank);u.setRoles(roles);if(active!=null)u.setActive(active);
  if(newPassword!=null&&!newPassword.isBlank())u.setPasswordHash(encoder.encode(newPassword));
  audit.log(u.getUsername(),"USER_UPDATE","Обновлён пользователь "+u.getUsername());return repo.save(u);
 }
 public void delete(Long id){User u=byId(id);audit.log(u.getUsername(),"USER_DELETE","Удалён пользователь "+u.getUsername());repo.delete(u);}
 public void touchLogin(String username){repo.findByUsername(username).ifPresent(u->{u.setLastLogin(LocalDateTime.now());repo.save(u);});}
 public String rolesString(User u){return u.getRoles().stream().map(Enum::name).sorted().reduce((a,b)->a+", "+b).orElse("—");}
}
