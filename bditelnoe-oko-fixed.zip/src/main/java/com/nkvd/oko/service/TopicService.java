package com.nkvd.oko.service;
import com.nkvd.oko.model.Topic;
import com.nkvd.oko.repo.TopicRepository;
import org.springframework.stereotype.Service;
import java.util.*;
@Service
public class TopicService {
 private final TopicRepository repo; private final AuditService audit;
 public TopicService(TopicRepository r,AuditService a){repo=r;audit=a;}
 public List<Topic> active(){return repo.findAllByArchivedFalseOrderByPriorityDesc();}
 public List<Topic> all(){return repo.findAll();}
 public Optional<Topic> find(Long id){return repo.findById(id);}
 public Topic save(Topic t){Topic s=repo.save(t);audit.log("system","TOPIC_SAVE","Тема "+s.getPrefix());return s;}
 public void delete(Long id){repo.deleteById(id);audit.log("system","TOPIC_DELETE","Удалена тема #"+id);}
}
