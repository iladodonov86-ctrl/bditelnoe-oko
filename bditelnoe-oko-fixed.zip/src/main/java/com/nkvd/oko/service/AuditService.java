package com.nkvd.oko.service;
import com.nkvd.oko.model.AuditLog;
import com.nkvd.oko.repo.AuditLogRepository;
import org.springframework.stereotype.Service;
import java.util.List;
@Service
public class AuditService {
 private final AuditLogRepository repo;
 public AuditService(AuditLogRepository repo){this.repo=repo;}
 public void log(String username,String action,String details){repo.save(new AuditLog(username,action,details));}
 public List<AuditLog> latest(){return repo.findTop200ByOrderByCreatedAtDesc();}
}
